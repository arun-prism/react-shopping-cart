// lambda/handler.js (or index.js)
exports.main = async function(event, context) {
    // Your Lambda handler logic here
  };